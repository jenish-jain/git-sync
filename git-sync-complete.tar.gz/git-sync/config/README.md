# Configuration

## sync-repos.json

This file contains the list of repositories to sync.

### Format

```json
[
  {
    "name": "repo-name"
  }
]
```

### Setup

1. Copy the example:
   ```bash
   cp sync-repos.example.json ~/sync-repos.json
   ```

2. Edit with your repositories:
   ```bash
   nano ~/sync-repos.json
   ```

3. Or auto-generate from GitHub:
   ```bash
   export GITHUB_TOKEN="your_token"
   python3 ../scripts/generate-config.py
   ```

### Examples

#### Manual Configuration
```json
[
  {"name": "my-project"},
  {"name": "website"},
  {"name": "scripts"}
]
```

#### Exclude Forks and Archived
```bash
curl -s -H "Authorization: token $GITHUB_TOKEN" \
  "https://api.github.com/users/YOUR_USERNAME/repos?per_page=100" | \
  jq '[.[] | select(.fork == false and .archived == false) | {name: .name}]' > ~/sync-repos.json
```
