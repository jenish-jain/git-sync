# Git Sync - Raspberry Pi GitHub Mirror

A complete solution for syncing GitHub repositories to your Raspberry Pi as a fault-tolerant backup system.

## 🎯 Features

- ✅ Automatic bidirectional sync between GitHub and local Git server
- ✅ Runs as systemd service with configurable intervals
- ✅ Auto-creates bare repositories
- ✅ Supports unlimited repositories via JSON config
- ✅ Comprehensive logging
- ✅ Secure token management
- ✅ Easy setup and maintenance

## 🚀 Quick Start

```bash
# Clone this repository
git clone https://github.com/jenishjain/git-sync.git
cd git-sync

# Run the setup script
chmod +x scripts/setup.sh
./scripts/setup.sh

# Edit configuration
nano ~/sync-repos.json

# Test manual sync
python3 /opt/git-sync/sync.py

# Check status
git-sync-status.sh
```

## 📖 Documentation

Comprehensive guides in the `docs/` directory:

1. [Raspberry Pi Setup](docs/01-raspberry-pi-setup.md) - Initial system configuration
2. [Git Server Setup](docs/02-git-server-setup.md) - Configure Git server
3. [Script Installation](docs/03-script-installation.md) - Install sync script
4. [Systemd Setup](docs/04-systemd-setup.md) - Automated syncing
5. [Usage Guide](docs/05-usage-guide.md) - Daily operations
6. [Troubleshooting](docs/06-troubleshooting.md) - Common issues

## ⚙️ Configuration

### 1. GitHub Token

Get token from: https://github.com/settings/tokens
- Scope required: `repo`

### 2. Repository List

Edit `~/sync-repos.json`:
```json
[
  {"name": "my-project"},
  {"name": "website"}
]
```

Or auto-generate:
```bash
export GITHUB_TOKEN="your_token"
python3 scripts/generate-config.py
```

## 🔧 Usage

```bash
# Check status
git-sync-status.sh

# Manual sync
sudo systemctl start git-sync.service

# View logs
sudo journalctl -u git-sync.service -f

# Clone from Pi
git clone you@raspberrypi.local:repositories/repo.git
```

## 📁 Project Structure

```
git-sync/
├── README.md
├── docs/              # Comprehensive documentation
├── scripts/           # Sync and utility scripts
├── config/            # Configuration examples
└── systemd/           # Service files
```

## 🛠️ Requirements

- Raspberry Pi with network connectivity
- Raspbian/Ubuntu OS
- Python 3.7+
- Git 2.0+
- GitHub account with Personal Access Token

## 📄 License

MIT License

## 👤 Author

**Jenish Jain**
- GitHub: [@jenishjain](https://github.com/jenishjain)

## 🙏 Acknowledgments

Built for reliable GitHub backup and redundancy.
