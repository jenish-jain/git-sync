# Full Documentation

The complete, detailed documentation guides (01-06) are available online in the GitHub repository:

https://github.com/jenishjain/git-sync/tree/main/docs

## Available Guides

1. **Raspberry Pi Setup** - Complete initial setup guide
2. **Git Server Setup** - Configure your Git server
3. **Script Installation** - Install and configure the sync script
4. **Systemd Setup** - Automate syncing with systemd
5. **Usage Guide** - Daily operations and workflows  
6. **Troubleshooting** - Solutions to common problems

## Quick Start Without Full Docs

If you just want to get started quickly:

```bash
# 1. Run setup script
./scripts/setup.sh

# 2. Edit your repo list
nano ~/sync-repos.json

# 3. Update username in script
nano /opt/git-sync/sync.py
# Change: "github_username": "YOUR_GITHUB_USERNAME"

# 4. Test
python3 /opt/git-sync/sync.py

# 5. Check status
git-sync-status.sh
```

## Key Configuration Files

- `~/sync-repos.json` - List of repositories to sync
- `/opt/git-sync/sync.py` - Main sync script (update USERNAME)
- `/etc/systemd/system/git-sync.env` - GitHub token (created by setup.sh)

## Common Commands

```bash
# Manual sync
sudo systemctl start git-sync.service

# Check status  
git-sync-status.sh

# View logs
sudo journalctl -u git-sync.service -f

# Stop/start timer
sudo systemctl stop git-sync.timer
sudo systemctl start git-sync.timer
```

## Need Help?

1. Check the online documentation (link above)
2. Review logs for errors
3. Open an issue on GitHub

