# Git Sync Documentation

Complete documentation for setting up and using Git Sync on Raspberry Pi.

## Guides

1. **01-raspberry-pi-setup.md** - Initial Raspberry Pi configuration
2. **02-git-server-setup.md** - Setting up Git server
3. **03-script-installation.md** - Installing the sync script
4. **04-systemd-setup.md** - Automating with systemd
5. **05-usage-guide.md** - Daily operations and usage
6. **06-troubleshooting.md** - Common issues and solutions

## Quick Links

- [Project README](../README.md)
- [Configuration Examples](../config/)
- [Scripts](../scripts/)

## Getting Help

1. Check the relevant documentation section
2. Review troubleshooting guide
3. Check logs: `sudo journalctl -u git-sync.service -f`
4. Open an issue on GitHub

## Documentation Structure

Each guide is self-contained but references others for additional context.
Start with guide 01 and proceed sequentially for initial setup.
