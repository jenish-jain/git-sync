#!/bin/bash
# Complete setup script for Git Sync

set -e

echo "======================================"
echo "  Git Sync - Complete Setup Script"
echo "======================================"
echo ""

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    echo "⚠️  Please don't run as root. Run as your regular user."
    exit 1
fi

echo "📋 Checking prerequisites..."

# Check Git
if ! command -v git &> /dev/null; then
    echo "❌ Git not found. Installing..."
    sudo apt update && sudo apt install -y git
else
    echo "✓ Git installed: $(git --version)"
fi

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 not found. Installing..."
    sudo apt install -y python3 python3-pip
else
    echo "✓ Python installed: $(python3 --version)"
fi

# Check pip packages
echo "✓ Installing Python packages..."
pip3 install requests --break-system-packages 2>/dev/null || pip3 install requests

echo ""
echo "📁 Creating directory structure..."
mkdir -p ~/repositories
mkdir -p ~/sync-workspace
mkdir -p ~/.ssh
chmod 700 ~/.ssh

echo "✓ Directories created"

echo ""
echo "🔧 Installing scripts..."
sudo mkdir -p /opt/git-sync
sudo cp scripts/sync.py /opt/git-sync/
sudo chown -R $USER:$USER /opt/git-sync
chmod +x /opt/git-sync/sync.py

sudo cp scripts/git-sync-status.sh /usr/local/bin/
sudo chmod +x /usr/local/bin/git-sync-status.sh

echo "✓ Scripts installed"

echo ""
echo "📝 Setting up configuration..."
if [ ! -f ~/sync-repos.json ]; then
    cp config/sync-repos.example.json ~/sync-repos.json
    echo "✓ Created ~/sync-repos.json (edit this file with your repositories)"
else
    echo "✓ ~/sync-repos.json already exists"
fi

echo ""
echo "🔐 Setting up GitHub token..."
if [ -z "$GITHUB_TOKEN" ]; then
    read -sp "Enter your GitHub Personal Access Token: " GITHUB_TOKEN
    echo ""
    echo "export GITHUB_TOKEN='$GITHUB_TOKEN'" >> ~/.bashrc
    export GITHUB_TOKEN="$GITHUB_TOKEN"
fi

sudo mkdir -p /etc/systemd/system
sudo bash -c "echo 'GITHUB_TOKEN=$GITHUB_TOKEN' > /etc/systemd/system/git-sync.env"
sudo chmod 600 /etc/systemd/system/git-sync.env
echo "✓ Token configured"

echo ""
echo "⚙️  Installing systemd services..."
sudo cp systemd/git-sync.service /etc/systemd/system/
sudo cp systemd/git-sync.timer /etc/systemd/system/

# Update username in service file
sudo sed -i "s/jenishjain/$USER/g" /etc/systemd/system/git-sync.service

sudo systemctl daemon-reload
sudo systemctl enable git-sync.timer
sudo systemctl start git-sync.timer

echo "✓ Systemd services installed and started"

echo ""
echo "======================================"
echo "✅ Setup Complete!"
echo "======================================"
echo ""
echo "Next steps:"
echo "1. Edit ~/sync-repos.json with your repositories"
echo "2. Update GitHub username in /opt/git-sync/sync.py"
echo "3. Test: python3 /opt/git-sync/sync.py"
echo "4. Check status: git-sync-status.sh"
echo ""
echo "The sync will run automatically every hour."
echo "View logs: sudo journalctl -u git-sync.service -f"
echo ""
