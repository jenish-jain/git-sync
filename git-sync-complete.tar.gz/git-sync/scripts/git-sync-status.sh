#!/bin/bash
# Git Sync Status Dashboard

echo "======================================"
echo "     Git Sync Status Dashboard"
echo "======================================"
echo ""

echo "📅 Current Time: $(date)"
echo ""

echo "⏰ Timer Status:"
if systemctl is-active git-sync.timer &> /dev/null; then
    echo "  ✓ Active"
else
    echo "  ✗ Inactive"
fi
echo ""

echo "🔄 Next Sync:"
systemctl list-timers 2>/dev/null | grep git-sync | awk '{print "  " $1, $2, $3, $4}' || echo "  No timer found"
echo ""

echo "📊 Last Sync:"
systemctl status git-sync.service --no-pager 2>/dev/null | grep -E "Started|Finished|Active" | tail -3 || echo "  Service not found"
echo ""

echo "📁 Repository Count:"
BARE_COUNT=$(ls -1 ~/repositories/ 2>/dev/null | wc -l)
MIRROR_COUNT=$(ls -1 ~/sync-workspace/ 2>/dev/null | wc -l)
echo "  Bare repos: $BARE_COUNT"
echo "  Mirror repos: $MIRROR_COUNT"
echo ""

echo "💾 Disk Usage:"
if [ -d ~/repositories/ ]; then
    echo "  Bare repos: $(du -sh ~/repositories/ 2>/dev/null | awk '{print $1}')"
fi
if [ -d ~/sync-workspace/ ]; then
    echo "  Mirror repos: $(du -sh ~/sync-workspace/ 2>/dev/null | awk '{print $1}')"
fi
echo ""

echo "📋 Recent Logs:"
if [ -f ~/git-sync.log ]; then
    tail -5 ~/git-sync.log 2>/dev/null || journalctl -u git-sync.service -n 5 --no-pager 2>/dev/null | tail -5
else
    journalctl -u git-sync.service -n 5 --no-pager 2>/dev/null | tail -5 || echo "  No logs found"
fi
echo ""
echo "======================================"
