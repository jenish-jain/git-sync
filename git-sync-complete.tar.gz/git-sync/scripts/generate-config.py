#!/usr/bin/env python3
"""
Generate sync-repos.json from GitHub account
"""
import requests
import json
import os
import sys

GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "")
GITHUB_USERNAME = input("Enter your GitHub username: ").strip()

if not GITHUB_TOKEN:
    print("ERROR: GITHUB_TOKEN environment variable not set!")
    print("Run: export GITHUB_TOKEN='your_token_here'")
    sys.exit(1)

headers = {"Authorization": f"token {GITHUB_TOKEN}"}
repos = []
page = 1

print(f"Fetching repositories for {GITHUB_USERNAME}...")

while True:
    url = f"https://api.github.com/users/{GITHUB_USERNAME}/repos?per_page=100&page={page}"
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print(f"Error: {response.status_code}")
        print(response.text)
        sys.exit(1)
    
    data = response.json()
    if not data:
        break
    
    for repo in data:
        if not repo['fork'] and not repo['archived']:
            repos.append({"name": repo["name"]})
    
    page += 1

output_file = os.path.expanduser("~/sync-repos.json")
with open(output_file, "w") as f:
    json.dump(repos, f, indent=2)

print(f"\n✓ Generated config with {len(repos)} repositories")
print(f"✓ Saved to: {output_file}")
print("\nRepositories:")
for repo in repos:
    print(f"  - {repo['name']}")
